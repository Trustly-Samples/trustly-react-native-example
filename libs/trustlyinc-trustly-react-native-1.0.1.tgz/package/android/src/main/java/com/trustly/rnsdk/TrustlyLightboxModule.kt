package com.trustly.rnsdk

import android.content.Intent
import com.facebook.react.bridge.Arguments
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod
import java.util.concurrent.atomic.AtomicReference

/**
 * React Native native module that opens the Trustly Lightbox using Chrome Custom Tabs —
 * mirroring the SecureBrowser strategy in the Trustly Android SDK (TrustlyLightbox.kt /
 * TrustlyCustomTabsManagerActivity.kt).
 *
 * Flow:
 *  1. JS calls `openCustomTabs(lightboxUrl)` with the redirect URL obtained from the
 *     Lightbox POST endpoint.
 *  2. This module starts TrustlyCustomTabsActivity, which launches Chrome Custom Tabs.
 *  3. After the auth flow completes, Chrome redirects to the app's URL scheme.
 *  4. TrustlyRedirectActivity intercepts the deep link and starts
 *     TrustlyCustomTabsActivity (singleTop + CLEAR_TOP) with the return URL.
 *  5. TrustlyCustomTabsActivity.onNewIntent receives the URL, resolves the promise,
 *     and finishes itself.
 *  6. If the user presses Back without completing the flow, onResume detects the
 *     abandoned session and resolves with { type: "cancel" }.
 */
class TrustlyLightboxModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    override fun getName(): String = MODULE_NAME

    /**
     * Opens Chrome Custom Tabs with [url]. The Promise resolves with one of:
     *   - { type: "success", url: "<return-url-with-query-params>" }
     *   - { type: "cancel" }
     *
     * This matches the shape returned by `InAppBrowser.openAuth()` so the JS layer
     * requires minimal changes.
     *
     * @param url        The lightbox redirect URL obtained from the POST to the endpoint.
     * @param promise    Resolved when the user completes or abandons the flow.
     */
    @ReactMethod
    fun openCustomTabs(url: String, promise: Promise) {
        pendingPromise.set(promise)
        val intent = Intent(reactContext, TrustlyCustomTabsActivity::class.java).apply {
            putExtra(TrustlyCustomTabsActivity.EXTRA_URL, url)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        }
        reactContext.startActivity(intent)
    }

    companion object {
        const val MODULE_NAME = "TrustlyLightbox"

        /**
         * Holds the in-flight promise. Uses AtomicReference for thread safety; the
         * Lightbox is designed for a single concurrent session.
         */
        private val pendingPromise = AtomicReference<Promise?>(null)

        /**
         * Called by TrustlyCustomTabsActivity when the auth flow returns a redirect URL.
         * Resolves the pending promise as a success.
         */
        fun resolveWithUrl(url: String) {
            pendingPromise.getAndSet(null)?.resolve(
                Arguments.createMap().apply {
                    putString("type", "success")
                    putString("url", url)
                }
            )
        }

        /**
         * Called by TrustlyCustomTabsActivity when the user dismisses the flow
         * without completing it (Back button) or when an error occurs.
         * Resolves the pending promise as a cancel.
         */
        fun resolveWithCancel() {
            pendingPromise.getAndSet(null)?.resolve(
                Arguments.createMap().apply {
                    putString("type", "cancel")
                }
            )
        }
    }
}

package com.trustly.rnsdk

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.os.Bundle
import androidx.browser.customtabs.CustomTabsIntent
import androidx.core.net.toUri
import android.util.Log

/**
 * Transparent activity that manages the Chrome Custom Tabs session for the
 * Trustly Lightbox flow. Mirrors TrustlyCustomTabsManagerActivity from the
 * Trustly Android SDK.
 *
 * Lifecycle:
 *
 *  ┌─ onCreate ──────────────────────────────────────────────────────────────┐
 *  │  Case A – Normal open (EXTRA_URL present):                              │
 *  │    - Launches Chrome Custom Tabs with the lightbox URL.                 │
 *  │    - onPause fires immediately after; sets customTabsOpened = true.     │
 *  │                                                                         │
 *  │  Case B – Return from TrustlyRedirectActivity (EXTRA_RETURN_URL set):  │
 *  │    Not reached via onCreate because launchMode=singleTop means          │
 *  │    onNewIntent is called on the existing instance instead.              │
 *  └─────────────────────────────────────────────────────────────────────────┘
 *
 *  ┌─ onNewIntent ───────────────────────────────────────────────────────────┐
 *  │  TrustlyRedirectActivity starts this activity with CLEAR_TOP +         │
 *  │  SINGLE_TOP and EXTRA_RETURN_URL. Android calls onNewIntent since       │
 *  │  launchMode=singleTop and the activity is already in the stack.         │
 *  │  - Updates this.intent so onResume can read EXTRA_RETURN_URL.           │
 *  └─────────────────────────────────────────────────────────────────────────┘
 *
 *  ┌─ onResume ──────────────────────────────────────────────────────────────┐
 *  │  First resume (after onCreate): customTabsOpened=false → no-op.        │
 *  │  After redirect (EXTRA_RETURN_URL set): resolve promise as success.     │
 *  │  After user presses Back in Chrome: resolve promise as cancel.          │
 *  └─────────────────────────────────────────────────────────────────────────┘
 */
class TrustlyCustomTabsActivity : Activity() {

    /** True after Custom Tabs has been launched (set in onPause). */
    private var customTabsOpened = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val url = intent.getStringExtra(EXTRA_URL) ?: run {
            TrustlyLightboxModule.resolveWithCancel()
            finish()
            return
        }
        openCustomTabs(url)
    }

    /**
     * Called by Android when TrustlyRedirectActivity restarts this singleTop activity
     * with FLAG_ACTIVITY_CLEAR_TOP | FLAG_ACTIVITY_SINGLE_TOP.
     * Updating this.intent ensures onResume picks up EXTRA_RETURN_URL.
     */
    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)

        Log.d("TrustlyCustomTabsActivity", "intent: ${intent}")
    }

    /**
     * Mark that Custom Tabs is now covering this activity.
     * This flag is used in onResume to distinguish the first resume (no-op)
     * from subsequent resumes (Custom Tabs dismissed or replaced).
     */
    override fun onPause() {
        super.onPause()
        if (!isFinishing) {
            customTabsOpened = true
        }
    }

    /**
     * Three cases on resume:
     *  1. First resume after onCreate (customTabsOpened=false) → no-op; wait for Custom Tabs.
     *  2. EXTRA_RETURN_URL is present (set via onNewIntent by TrustlyRedirectActivity)
     *     → auth completed successfully, resolve promise and finish.
     *  3. No return URL but customTabsOpened=true → user pressed Back in Chrome,
     *     resolve promise as cancel and finish.
     */
    override fun onResume() {
        super.onResume()
        val returnUrl = intent.getStringExtra(EXTRA_RETURN_URL)

        Log.d("TrustlyCustomTabsActivity", "returnUrl: ${returnUrl}")

        if (returnUrl != null) {
            val splitReturnUrl = returnUrl!!.split("//")

            Log.d("TrustlyCustomTabsActivity", "url: ${splitReturnUrl[1]}")

            when {
                splitReturnUrl[1] != null -> {
                    TrustlyLightboxModule.resolveWithUrl(splitReturnUrl[1])
                    finish()
                }
                customTabsOpened -> {
                    TrustlyLightboxModule.resolveWithCancel()
                    finish()
                }
            }
        } else {
            Log.d("TrustlyCustomTabsActivity", "url is null")
        }
    }

    private fun openCustomTabs(url: String) {
        try {
            val customTabsIntent = CustomTabsIntent.Builder().build().apply {
                // Force Chrome for a consistent browser experience, matching the
                // Android SDK's TrustlyCustomTabsManagerActivity behaviour.
                intent.setPackage("com.android.chrome")
            }
            customTabsIntent.launchUrl(this, url.toUri())
        } catch (_: Exception) {
            showBrowserRequiredDialog()
        }
    }

    private fun showBrowserRequiredDialog() {
        AlertDialog.Builder(this)
            .setTitle("Google Chrome browser required")
            .setMessage(
                "This feature requires Google Chrome. " +
                "Please install or enable Chrome from the Google Play Store to continue."
            )
            .setPositiveButton("OK") { dialog, _ ->
                dialog.dismiss()
                TrustlyLightboxModule.resolveWithCancel()
                finish()
            }
            .show()
    }

    companion object {
        /** Lightbox redirect URL to open in Chrome Custom Tabs. */
        const val EXTRA_URL = "TRUSTLY_URL"

        /**
         * Full return URL (including query params) passed back by TrustlyRedirectActivity
         * after the auth deep-link is intercepted.
         */
        const val EXTRA_RETURN_URL = "TRUSTLY_RETURN_URL"
    }
}
